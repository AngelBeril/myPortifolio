package com.student.rmk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RmkApplicationTests {

	@Test
	void contextLoads() {
	}

}

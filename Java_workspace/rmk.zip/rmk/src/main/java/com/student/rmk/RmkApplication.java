package com.student.rmk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RmkApplication {

	public static void main(String[] args) {
		SpringApplication.run(RmkApplication.class, args);
	}

}
